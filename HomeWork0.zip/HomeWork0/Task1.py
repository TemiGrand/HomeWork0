first = 73
second = 52
summa = first + second
diff = first - second
print('Даны числа:', first, 'и', second,
      '\nСумма =', summa,
      '\nРазность =', diff)