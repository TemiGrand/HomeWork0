first = 73
second = 52
third = 3
mean = (first + second + third)/3
print('Даны числа:', str(first) + ',', second, 'и', third,
      '\nСреднее арифметическое =', mean)