a = 3
b = 5
c = 2
f = (a * b) + (a * c)
g = (f**3)/2
print(g)
