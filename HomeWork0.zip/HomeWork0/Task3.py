first_string = "Вторник"
second_string = "Понедельник"
print(second_string + ',', first_string)
